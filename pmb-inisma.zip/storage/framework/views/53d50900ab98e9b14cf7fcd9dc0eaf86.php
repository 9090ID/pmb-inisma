<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Pendaftaran</title>
</head>
<body>
    <h1>Selamat, <?php echo e($name); ?>!</h1>
    <p>Anda telah berhasil mendaftar. Berikut adalah detail akun Anda:</p>
    <p>Nomor Registrasi Anda : <?php echo e($nomor_registrasi); ?></p> <!-- Tampilkan nomor registrasi -->
    <p><strong>Username:</strong> <?php echo e($email); ?></p>
    <p><strong>Password:</strong> <?php echo e($password); ?></p>
    <p>Silakan login untuk melanjutkan proses Berikutnya. <a href="http://127.0.0.1:8000/login"> Login</a></p>
</body>
</html><?php /**PATH D:\GITHUB\pmb-inisma\resources\views/pendaftaran/konfirmasi.blade.php ENDPATH**/ ?>