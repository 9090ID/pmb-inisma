<header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

      <a href="/" class="logo d-flex align-items-center me-auto">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
      <img src="<?php echo e(asset('inisma/logo.webp')); ?>" alt="inisma">   
      <h1 class="sitename d-none d-sm-block">PMB Insitut Islam Muaro Jambi</h1>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="<?php echo e(url('/#hero')); ?>" class="active">Home</a></li>
          <li><a href="<?php echo e(url('/#about')); ?>">Jadwal</a></li>
          <li><a href="<?php echo e(url('/#services')); ?>">Jalur Seleksi</a></li>
          <li><a href="<?php echo e(url('/#portofolio')); ?>">Biaya Studi</a></li>
          <li><a href="<?php echo e(url('/#team')); ?>">Fakultas</a></li>
          
          
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

      <a class="cta-btn" href="/daftar-pmb">Daftar</a>

    </div>
  </header><?php /**PATH D:\GITHUB\pmb-inisma\resources\views/landingpage/template/header.blade.php ENDPATH**/ ?>