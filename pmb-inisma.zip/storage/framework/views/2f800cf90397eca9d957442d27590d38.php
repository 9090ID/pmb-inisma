  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('home/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/vendor/php-email-form/validate.js')); ?>"></script>
  <script src="<?php echo e(asset('home/vendor/aos/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('home/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/vendor/purecounter/purecounter_vanilla.js')); ?>"></script>
  <script src="<?php echo e(asset('home/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/vendor/imagesloaded/imagesloaded.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('home/vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/core/jquery-3.7.1.min.js')); ?>"></script>
  <!-- Main JS File -->
  <script src="<?php echo e(asset('home/js/main.js')); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<?php /**PATH D:\GITHUB\pmb-inisma\resources\views/landingpage/template/scripts.blade.php ENDPATH**/ ?>