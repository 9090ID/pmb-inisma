<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->make('landingpage.template.metadata', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Favicons -->
  <link href="<?php echo e(asset('inisma/logo.ico')); ?>" rel="icon">
  <link href="<?php echo e(asset('home/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

  <!--head-->
  <?php echo $__env->make('landingpage.template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
</head>
<body class="index-page">

    <!-- ======= Header ======= -->
    <?php echo $__env->make('landingpage.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Header -->
    <!--Main-->
    <?php echo $__env->yieldContent('content'); ?>
    <!--end main-->

  <!--footer-->
  <?php echo $__env->make('landingpage.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--end footer-->

   
  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>
  <!-- Vendor JS Files -->
  <?php echo $__env->make('landingpage.template.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html><?php /**PATH D:\GITHUB\pmb-inisma\resources\views/landingpage/start.blade.php ENDPATH**/ ?>