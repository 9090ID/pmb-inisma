<div class="py-6 px-6 text-center">
    <p class="mb-0 fs-4"> Hak Cipta © 2025 Insitut Islam Muaro Jambi. All rights reserved - Laman Web : <a href="/">inisma.ac.id</a></p>
  </div>