    <script src="{{asset('mahasiswa/libs/jquery/dist/jquery.min.js')}}"></script>
  <script src="{{asset('mahasiswa/libs/bootstrap/dist/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('mahasiswa/js/sidebarmenu.js')}}"></script>
  <script src="{{asset('mahasiswa/js/app.min.js')}}"></script>
  <script src="{{asset('mahasiswa/libs/apexcharts/dist/apexcharts.min.js')}}"></script>
  <script src="{{asset('mahasiswa/libs/simplebar/dist/simplebar.js')}}"></script>
  <script src="{{asset('mahasiswa/js/dashboard.js')}}"></script>

  @stack('scripts')